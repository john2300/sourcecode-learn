module.exports = {
    output: {
        filename: "scripts/[name].[hash:5].bundles.js",
        publicPath: "/"
    }
}