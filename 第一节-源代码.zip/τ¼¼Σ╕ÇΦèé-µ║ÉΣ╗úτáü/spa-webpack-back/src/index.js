import {
    sync
} from "./components/sync/index.js";
console.log("Hello Yideng Webpack");
sync();