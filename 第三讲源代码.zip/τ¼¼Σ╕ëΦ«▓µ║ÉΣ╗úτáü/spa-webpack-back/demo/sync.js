export default {
    init(){
        console.log("init");
    }
}