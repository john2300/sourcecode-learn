import sync from "./sync.js";
sync.init();

