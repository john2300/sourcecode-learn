function util(){
    
}
// var 
util.isString = function(node){
    return typeof node === "string";
}

export default util;