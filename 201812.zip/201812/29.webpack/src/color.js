export default "zfpx2";
throw Error('Wrong');