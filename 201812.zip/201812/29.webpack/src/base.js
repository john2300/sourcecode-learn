let b2 = require('./b2');
$('#base').html('base');