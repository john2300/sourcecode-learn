[./node_modules/loglevel / lib / loglevel.js] 7.68 KiB { main } [built]
[./ node_modules / querystring - es3 / index.js] 127 bytes { main } [built]
[./ node_modules / sockjs - client / dist / sockjs.js] 176 KiB { main } [built]
[./ node_modules / style - loader / lib / addStyles.js] 9.69 KiB { main } [built]
[./ node_modules / url / url.js] 22.8 KiB { main } [built]
[0] multi(webpack) - dev - server / client ? http ://localhost:8080 ./src/index.js 40
    bytes { main } [built]