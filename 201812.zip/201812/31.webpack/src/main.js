import {getName} from './info.js';
let r = getName();
console.log(r);