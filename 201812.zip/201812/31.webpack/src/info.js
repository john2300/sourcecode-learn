export function getName(){
    return 'zfpx';
}
export function getAge(){
    return 9;
}