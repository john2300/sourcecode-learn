import name from './h';
console.log(name);