function one() {
  let a = 'a';
  console.log(1);
  function two() {
    let b = 'b';
    console.log(2);
  }
  two();
}
one();
