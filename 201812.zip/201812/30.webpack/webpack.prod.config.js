const path = require('path');
const webpack = require('webpack');
module.exports = {
    output: {
        publicPath: "http://img.zhufengpeixun.cn"
    }
}