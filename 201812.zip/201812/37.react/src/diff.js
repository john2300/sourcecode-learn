let before = [1,2,3];
let after = [4,1,2,3]