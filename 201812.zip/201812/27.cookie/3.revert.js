
console.log(decodeURIComponent('s%3Azfpx.%2Ffl56ix3wcE%2BNLeDcWO%2BHcRW2Ucclhe4CnQvZKr%2BayY'));