import banner from "../components/banner/banner.js";
banner();