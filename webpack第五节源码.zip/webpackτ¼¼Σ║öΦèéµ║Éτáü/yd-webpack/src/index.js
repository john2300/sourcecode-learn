const result = require("./test.js")
result();