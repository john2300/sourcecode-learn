const result = ()=>{
    console.log("京程一灯");
}
module.exports = result;