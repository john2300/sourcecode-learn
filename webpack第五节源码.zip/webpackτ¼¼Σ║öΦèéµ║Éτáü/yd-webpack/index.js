const result = require("./test.js");
//const s = require("");
result();