while(true){
   postMessage(Math.random());
}