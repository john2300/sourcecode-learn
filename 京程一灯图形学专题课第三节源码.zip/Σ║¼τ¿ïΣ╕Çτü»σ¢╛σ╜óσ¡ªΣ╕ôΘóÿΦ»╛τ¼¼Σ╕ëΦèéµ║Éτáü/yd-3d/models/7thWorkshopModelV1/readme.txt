由于模型的特殊性 暂时并不能提供给大家。
大家可以在https://sketchfab.com/下载自己喜欢的模型